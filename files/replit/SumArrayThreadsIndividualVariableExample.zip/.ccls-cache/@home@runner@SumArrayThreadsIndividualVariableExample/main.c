#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

/**
 * Allocates and populates an array of integers.
 * 
 * @param num_elements The number of elements in the array.
 * @return A pointer to the allocated array, or NULL if memory allocation fails.
 */
long* create_and_fill_array(int num_elements) {
    // Allocate memory for the array
    long* array = (long*) malloc(num_elements * sizeof(long));

    // Check if memory allocation was successful
    if (array == NULL) {
        return NULL; // Memory allocation failed, return NULL
    }

    // Populate the array
    for (int i = 0; i < num_elements; i++) {
        array[i] = i; // Example: fill with sequential numbers starting from 0
    }

    // Return the pointer to the newly created array
    return array;
}

// Define a structure to hold thread data
typedef struct {
    long *array;       // Array of integers
    int start;        // Starting index for this thread to begin summing
    int end;          // Ending index for this thread to stop summing
    long *partial_sums; // Array for storing partial sums, shared among threads
    int index;        // Index in the partial_sums array where this thread will write its sum
} ThreadData;

// Thread function to calculate the sum of a part of the array
void *calculate_partial_sum(void *arg) {
    ThreadData *data = (ThreadData *)arg;

    long sum = 0;
    for (int i = data->start; i < data->end; i++) {
        sum += data->array[i];
    }

    // Write the partial sum to the designated slot
    data->partial_sums[data->index] = sum;

    pthread_exit(NULL);
}

int main() {
    const int NUM_THREADS = 2;
    const int ARRAY_SIZE = 1000000; // Change as needed
    long* array = create_and_fill_array(ARRAY_SIZE);
    long partial_sums[NUM_THREADS] = {0}; // Array for the partial sums
    ThreadData threadData[NUM_THREADS];
    pthread_t threads[NUM_THREADS];

    // Initialize thread data and create threads
    for (int i = 0; i < NUM_THREADS; i++) {
        threadData[i].array = array;
        threadData[i].start = i * (ARRAY_SIZE / NUM_THREADS);
        threadData[i].end = (i + 1) * (ARRAY_SIZE / NUM_THREADS);
        threadData[i].partial_sums = partial_sums;
        threadData[i].index = i; // Each thread writes to its own index
        pthread_create(&threads[i], NULL, calculate_partial_sum, (void *)&threadData[i]);
    }

    // Wait for all threads to complete
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    // Sum the partial sums
    long total_sum = 0;
    for (int i = 0; i < NUM_THREADS; i++) {
        total_sum += partial_sums[i];
    }

    // Print the total sum
    printf("Total sum: %ld\n", total_sum);

    // Clean up and exit
    free(array);
    pthread_exit(NULL);
}
