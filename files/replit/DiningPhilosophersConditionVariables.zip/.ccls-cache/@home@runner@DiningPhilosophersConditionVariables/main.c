#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_PHILOSOPHERS 5

pthread_mutex_t mutex;
pthread_cond_t cond[NUM_PHILOSOPHERS];
int chopstick[NUM_PHILOSOPHERS] = {0};

void *philosopher(void *arg) {
    int philosopher_id = *((int *)arg);
    int left_chopstick = philosopher_id;
    int right_chopstick = (philosopher_id + 1) % NUM_PHILOSOPHERS;

    while (1) {
        // Thinking
        printf("Philosopher %d is thinking\n", philosopher_id);
        usleep(rand() % 1000000);

        pthread_mutex_lock(&mutex);
        while (chopstick[left_chopstick] || chopstick[right_chopstick]) {
            pthread_cond_wait(&cond[philosopher_id], &mutex);
        }

        // Pick up chopsticks
        chopstick[left_chopstick] = 1;
        printf("Philosopher %d picks up left chopstick %d\n", philosopher_id, left_chopstick);
        chopstick[right_chopstick] = 1;
        printf("Philosopher %d picks up right chopstick %d\n", philosopher_id, right_chopstick);

        pthread_mutex_unlock(&mutex);

        // Eating
        printf("Philosopher %d is eating\n", philosopher_id);
        usleep(rand() % 1000000);

        pthread_mutex_lock(&mutex);

        // Put down chopsticks
        chopstick[left_chopstick] = 0;
        printf("Philosopher %d puts down left chopstick %d\n", philosopher_id, left_chopstick);
        chopstick[right_chopstick] = 0;
        printf("Philosopher %d puts down right chopstick %d\n", philosopher_id, right_chopstick);

        // Signal neighbors
        pthread_cond_signal(&cond[left_chopstick]);
        pthread_cond_signal(&cond[right_chopstick]);

        pthread_mutex_unlock(&mutex);
    }
}

int main() {
    int i;
    int philosopher_id[NUM_PHILOSOPHERS];

    // Initialize mutex and condition variables
    pthread_mutex_init(&mutex, NULL);
    for (i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_cond_init(&cond[i], NULL);
    }

    // Create threads for philosophers
    pthread_t philosophers[NUM_PHILOSOPHERS];
    for (i = 0; i < NUM_PHILOSOPHERS; i++) {
        philosopher_id[i] = i;
        pthread_create(&philosophers[i], NULL, philosopher, &philosopher_id[i]);
    }

    // Join threads
    for (i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_join(philosophers[i], NULL);
    }

    // Destroy mutex and condition variables
    pthread_mutex_destroy(&mutex);
    for (i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_cond_destroy(&cond[i]);
    }

    return 0;
}
