#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define NUM_PHILOSOPHERS 5

sem_t chopsticks[NUM_PHILOSOPHERS];

void *philosopher(void *arg) {
  int philosopher_id = *((int *)arg);
  int left_chopstick = philosopher_id;
  int right_chopstick = (philosopher_id + 1) % NUM_PHILOSOPHERS;

  while (1) {
    // Thinking
    printf("Philosopher %d is thinking\n", philosopher_id);
    usleep(rand() % 1000000);

    // Pick up chopsticks
    if (philosopher_id % 2 == 0) {
      sem_wait(&chopsticks[left_chopstick]);
      printf("Philosopher %d picks up left chopstick %d\n", philosopher_id, left_chopstick);
      sem_wait(&chopsticks[right_chopstick]);
      printf("Philosopher %d picks up right chopstick %d\n", philosopher_id, right_chopstick);
    } else {
      sem_wait(&chopsticks[right_chopstick]);
      printf("Philosopher %d picks up right chopstick %d\n", philosopher_id, right_chopstick);
      sem_wait(&chopsticks[left_chopstick]);
      printf("Philosopher %d picks up left chopstick %d\n", philosopher_id,
         left_chopstick);      
    }

    // Eating
    printf("Philosopher %d is eating\n", philosopher_id);
    usleep(rand() % 1000000);

    // Put down chopsticks
    sem_post(&chopsticks[right_chopstick]);
    printf("Philosopher %d puts down right chopstick %d\n", philosopher_id, right_chopstick);
    sem_post(&chopsticks[left_chopstick]);
    printf("Philosopher %d puts down left chopstick %d\n", philosopher_id, left_chopstick);
  }
}

int main() {
  int i;
  int philosopher_id[NUM_PHILOSOPHERS];

  // Initialize semaphores for chopsticks
  for (i = 0; i < NUM_PHILOSOPHERS; i++) {
    // sem, shared between processes, initial value
    sem_init(&chopsticks[i], 0, 1);
  }

  // Create threads for philosophers
  pthread_t philosophers[NUM_PHILOSOPHERS];
  for (i = 0; i < NUM_PHILOSOPHERS; i++) {
    philosopher_id[i] = i;
    pthread_create(&philosophers[i], NULL, philosopher, &philosopher_id[i]);
  }

  // Join threads
  for (i = 0; i < NUM_PHILOSOPHERS; i++) {
    pthread_join(philosophers[i], NULL);
  }

  // Destroy semaphores
  for (i = 0; i < NUM_PHILOSOPHERS; i++) {
    sem_destroy(&chopsticks[i]);
  }

  return 0;
}
