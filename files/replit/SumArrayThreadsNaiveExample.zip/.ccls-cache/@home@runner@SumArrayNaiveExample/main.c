#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

// Define a structure to hold thread data
typedef struct {
    int *array;          // Array of integers
    int start;           // Starting index for this thread to begin summing
    int end;             // Ending index for this thread to stop summing
    pthread_mutex_t *mutex; // Pointer to a shared mutex for synchronization
} ThreadData;

// Shared sum variable
int shared_sum = 0;

// Thread function to add each element to the shared sum directly, using a lock each time
void *update_shared_sum(void *arg) {
    ThreadData *data = (ThreadData *)arg;

    for (int i = data->start; i < data->end; i++) {
        // Lock the mutex before updating the shared sum
        pthread_mutex_lock(data->mutex);
        shared_sum += data->array[i];
        pthread_mutex_unlock(data->mutex);
    }

    pthread_exit(NULL);
}

int main() {
    const int NUM_THREADS = 2;
    const int ARRAY_SIZE = 10; // Change as needed
    int array[ARRAY_SIZE] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; // Example array
    ThreadData threadData[NUM_THREADS];
    pthread_t threads[NUM_THREADS];
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

    // Initialize thread data and create threads
    for (int i = 0; i < NUM_THREADS; i++) {
        threadData[i].array = array;
        threadData[i].start = i * (ARRAY_SIZE / NUM_THREADS);
        threadData[i].end = (i + 1) * (ARRAY_SIZE / NUM_THREADS);
        threadData[i].mutex = &mutex;
        pthread_create(&threads[i], NULL, update_shared_sum, (void *)&threadData[i]);
    }

    // Wait for all threads to complete
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    // Print the final shared sum
    printf("Total sum: %d\n", shared_sum);

    // Clean up and exit
    pthread_mutex_destroy(&mutex);
    pthread_exit(NULL);
}
