#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/slab.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A simple example Linux module.");
MODULE_VERSION("0.01");

static LIST_HEAD(my_list);

struct my_struct {
    int data;
    struct list_head list;
};

static int __init list_module_init(void) {
    struct my_struct *new_element;
    int i;

    printk(KERN_INFO "Loading Module\n");

    // Add 5 elements to the list
    for (i = 0; i < 5; i++) {
        new_element = kmalloc(sizeof(*new_element), GFP_KERNEL);
        if (!new_element) {
            printk(KERN_INFO "Memory allocation failed for new_element\n");
            return -ENOMEM;
        }

        new_element->data = i;
        INIT_LIST_HEAD(&new_element->list);
        list_add_tail(&new_element->list, &my_list);
    }

    struct my_struct *ptr;
    list_for_each_entry(ptr, &my_list, list) {
        printk(KERN_INFO "List Data: %d\n", ptr->data);
    }

    return 0;
}

static void __exit list_module_exit(void) {
    struct my_struct *ptr, *next;
    list_for_each_entry_safe(ptr, next, &my_list, list) {
        list_del(&ptr->list);
        kfree(ptr);
    }
    printk(KERN_INFO "Removing Module\n");
}

module_init(list_module_init);
module_exit(list_module_exit);

/*
Makefile that would go in the module directory within the kernel source tree:
# This is a comment line in the Makefile
# The Makefile for compiling the kernel module

obj-m += list_module.o

all:
  make -C /lib/modules/$(shell uname -r)/build M=$(PWD) modules

clean:
  make -C /lib/modules/$(shell uname -r)/build M=$(PWD) clean
*/