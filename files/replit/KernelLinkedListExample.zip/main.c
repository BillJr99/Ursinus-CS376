#include <stdio.h>
#include <stdlib.h>

// This is a user-space abstraction of the kernel definition

struct list_head {
  struct list_head *next, *prev;
};

#define LIST_HEAD_INIT(name)                                                   \
  { &(name), &(name) }

#define LIST_HEAD(name) struct list_head name = LIST_HEAD_INIT(name)

#define INIT_LIST_HEAD(ptr)                                                    \
  do {                                                                         \
    (ptr)->next = (ptr);                                                       \
    (ptr)->prev = (ptr);                                                       \
  } while (0)

static inline void __list_add(struct list_head *new, struct list_head *prev,
                              struct list_head *next) {
  next->prev = new;
  new->next = next;
  new->prev = prev;
  prev->next = new;
}

#define list_add_tail(new, head) __list_add(new, (head)->prev, (head))

#define list_entry(ptr, type, member)                                          \
  ((type *)((char *)(ptr) - (unsigned long)(&((type *)0)->member)))

#define list_for_each_entry_safe(pos, n, head, member)                         \
  for (pos = list_entry((head)->next, typeof(*pos), member),                   \
      n = list_entry(pos->member.next, typeof(*pos), member);                  \
       &pos->member != (head);                                                 \
       pos = n, n = list_entry(n->member.next, typeof(*n), member))

static inline void __list_del(struct list_head *prev, struct list_head *next) {
  next->prev = prev;
  prev->next = next;
}

#define list_del(entry)                                                        \
  {                                                                            \
    __list_del((entry)->prev, (entry)->next);                                  \
    (entry)->next = NULL;                                                      \
    (entry)->prev = NULL;                                                      \
  }

struct my_struct {
  int data;
  struct list_head list;
};

void add_to_list(struct list_head *head, int data) {
  struct my_struct *new_element = malloc(sizeof(struct my_struct));
  if (!new_element) {
    perror("Failed to allocate memory for new element");
    exit(EXIT_FAILURE);
  }
  new_element->data = data;
  INIT_LIST_HEAD(&new_element->list);
  list_add_tail(&new_element->list, head);
}

void print_and_free_list(struct list_head *head) {
  struct my_struct *pos, *n;
  list_for_each_entry_safe(pos, n, head, list) {
    printf("Data: %d\n", pos->data);
    list_del(&pos->list);
    free(pos);
  }
}

int main(void) {
  LIST_HEAD(my_list_head);

  add_to_list(&my_list_head, 1);
  add_to_list(&my_list_head, 2);
  add_to_list(&my_list_head, 3);

  print_and_free_list(&my_list_head);

  return 0;
}
